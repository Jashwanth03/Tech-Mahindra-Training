class AppStrings {
  static const String placeholderImageUrl = 'https://via.placeholder.com/150';
}
