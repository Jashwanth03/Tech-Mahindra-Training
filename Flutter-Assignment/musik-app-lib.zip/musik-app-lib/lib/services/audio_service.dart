// import 'package:audioplayers/audioplayers.dart';

// class AudioService {
//   final AudioPlayer _audioPlayer = AudioPlayer();

//   Future<void> play(String url) async {
//     try {
//       print('Attempting to play: $url');
//       await _audioPlayer.play(UrlSource(url));
//       print('Playing audio successfully');
//     } catch (e) {
//       print('Playback error: $e');
//       rethrow;
//     }
//   }

//   Future<void> pause() async {
//     try {
//       await _audioPlayer.pause();
//       print('Paused audio');
//     } catch (e) {
//       print('Pause error: $e');
//       rethrow;
//     }
//   }
// }
